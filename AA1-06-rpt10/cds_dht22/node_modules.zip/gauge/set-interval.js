'use strict'
// this exists so we can replace it during testing
module.exports = setInterval
